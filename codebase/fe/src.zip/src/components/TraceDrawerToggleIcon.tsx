import { PanelRightClose, PanelRightOpen } from "lucide-react";

type TraceDrawerToggleIconProps = {
  open: boolean;
  onToggle: () => void;
};

export default function TraceDrawerToggleIcon({
  open,
  onToggle,
}: TraceDrawerToggleIconProps) {
  return (
    <button
      className="absolute right-0 top-1/2 z-30 flex h-14 w-14 translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-2xl border border-slate-200 bg-white/95 text-slate-700 shadow-xl shadow-slate-900/10 backdrop-blur transition hover:border-slate-300 hover:text-slate-900"
      type="button"
      onClick={onToggle}
      aria-label={open ? "Đóng Agent Trace" : "Mở Agent Trace"}
    >
      {open ? <PanelRightClose className="h-6 w-6" /> : <PanelRightOpen className="h-6 w-6" />}
    </button>
  );
}
