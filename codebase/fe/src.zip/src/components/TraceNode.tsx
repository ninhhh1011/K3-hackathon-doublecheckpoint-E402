import {
  Bot,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleDashed,
  GitBranch,
  Search,
  TriangleAlert,
  Wrench,
} from "lucide-react";
import { useEffect, useState } from "react";

import type { TraceStep } from "../reading-assistant.types";

type TraceNodeProps = {
  step: TraceStep;
  isLast: boolean;
  defaultExpanded?: boolean;
};

function iconForStep(step: TraceStep) {
  if (step.status === "error") {
    return TriangleAlert;
  }
  switch (step.nodeType) {
    case "router":
      return GitBranch;
    case "tool_call":
      return Wrench;
    case "retrieval":
      return Search;
    case "llm_generation":
      return Bot;
    case "conditional_edge":
      return GitBranch;
  }
}

function statusClass(status: TraceStep["status"]): string {
  if (status === "completed") {
    return "border-emerald-200 bg-emerald-50 text-emerald-700";
  }
  if (status === "error") {
    return "border-rose-200 bg-rose-50 text-rose-700";
  }
  if (status === "running") {
    return "border-sky-200 bg-sky-50 text-sky-700";
  }
  return "border-slate-200 bg-slate-50 text-slate-500";
}

export default function TraceNode({
  step,
  isLast,
  defaultExpanded = false,
}: TraceNodeProps) {
  const [expanded, setExpanded] = useState(defaultExpanded);
  const Icon = iconForStep(step);

  useEffect(() => {
    setExpanded(defaultExpanded);
  }, [defaultExpanded]);

  return (
    <div className="relative pl-14">
      {!isLast && (
        <div className="absolute left-[21px] top-10 h-[calc(100%-1.25rem)] w-px bg-slate-200" />
      )}
      <div
        className={`absolute left-0 top-1 flex h-11 w-11 items-center justify-center rounded-2xl border ${statusClass(step.status)}`}
      >
        <Icon className="h-5 w-5" />
      </div>
      <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
        <button
          className="flex w-full items-start justify-between gap-4 text-left"
          type="button"
          onClick={() => setExpanded((value) => !value)}
        >
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-semibold text-slate-900">
                {step.label}
              </span>
              <span
                className={`inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[11px] font-medium ${statusClass(step.status)}`}
              >
                {step.status === "completed" ? (
                  <CheckCircle2 className="h-3.5 w-3.5" />
                ) : (
                  <CircleDashed className="h-3.5 w-3.5" />
                )}
                {step.status}
              </span>
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {step.toolName ?? step.branchLabel ?? step.nodeType}
            </div>
          </div>
          {expanded ? (
            <ChevronDown className="mt-1 h-4 w-4 shrink-0 text-slate-500" />
          ) : (
            <ChevronRight className="mt-1 h-4 w-4 shrink-0 text-slate-500" />
          )}
        </button>

        {expanded && (
          <div className="mt-4 grid gap-3 rounded-2xl bg-slate-50 p-3 text-xs text-slate-700">
            {step.input !== undefined && (
              <div>
                <div className="mb-1 font-semibold text-slate-900">Input</div>
                <pre className="overflow-auto rounded-2xl bg-white p-3 text-[11px] leading-5">
                  {JSON.stringify(step.input, null, 2)}
                </pre>
              </div>
            )}
            {step.output !== undefined && (
              <div>
                <div className="mb-1 font-semibold text-slate-900">Output</div>
                <pre className="overflow-auto rounded-2xl bg-white p-3 text-[11px] leading-5">
                  {JSON.stringify(step.output, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
