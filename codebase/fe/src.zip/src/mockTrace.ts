import type {
  ChatMessage,
  PendingContext,
  TraceStep,
  TraceStreamEvent,
} from "./reading-assistant.types";

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
}

function createAnswer(question: string, contexts: PendingContext[], pageNumber: number): string {
  const textCount = contexts.filter((item) => item.type === "text").length;
  const imageCount = contexts.filter((item) => item.type === "image").length;
  const fileCount = contexts.filter((item) => item.type === "file").length;

  return [
    `Mình đã đọc ngữ cảnh từ trang ${pageNumber} và thấy ${textCount} đoạn văn bản, ${imageCount} ảnh, ${fileCount} tệp đính kèm.`,
    `Với câu hỏi "${question || "giải thích nội dung này"}", hướng xử lý hợp lý là ưu tiên retrieval theo slide hiện tại, sau đó dùng OCR cho ảnh và đọc metadata của tệp nếu có.`,
    "Kết luận demo: bạn có thể hỏi tự do, gửi kèm attachment và xem toàn bộ trace node để đối chiếu cách agent suy luận.",
  ].join("\n\n");
}

export async function streamMockAgentRun(
  question: string,
  contexts: PendingContext[],
  pageNumber: number,
  onEvent: (event: TraceStreamEvent) => void,
): Promise<ChatMessage> {
  const sharedPayload = {
    question,
    pageNumber,
    textContexts: contexts.filter((item) => item.type === "text").length,
    imageContexts: contexts.filter((item) => item.type === "image").length,
    fileContexts: contexts.filter((item) => item.type === "file").length,
  };

  const hasImage = contexts.some((item) => item.type === "image");
  const hasFile = contexts.some((item) => item.type === "file");

  const events: Array<{ delay: number; event: TraceStreamEvent }> = [
    {
      delay: 180,
      event: {
        type: "node_start",
        nodeId: "planner",
        nodeType: "router",
        label: "Router / Planner node",
        payload: { input: sharedPayload, branchLabel: "phân tích câu hỏi" },
      },
    },
    {
      delay: 400,
      event: {
        type: "node_end",
        nodeId: "planner",
        payload: {
          output: {
            route: hasImage || hasFile ? "retrieval+attachments" : "retrieval-only",
          },
        },
      },
    },
    {
      delay: 220,
      event: {
        type: "node_start",
        nodeId: "condition",
        nodeType: "conditional_edge",
        label: "Conditional edge",
        payload: {
          input: { hasImageContext: hasImage, hasFileContext: hasFile },
          branchLabel:
            hasImage || hasFile
              ? "nếu có attachment -> xử lý bổ sung"
              : "ngược lại -> chỉ truy xuất văn bản",
        },
      },
    },
    {
      delay: 180,
      event: {
        type: "node_end",
        nodeId: "condition",
        payload: {
          output: {
            chosenBranch: hasImage || hasFile ? "if" : "else",
          },
        },
      },
    },
    {
      delay: 220,
      event: {
        type: "node_start",
        nodeId: "retrieval",
        nodeType: "retrieval",
        label: "Retrieval node",
        payload: {
          input: { pageNumber, vectorFilter: { activePage: pageNumber } },
        },
      },
    },
    {
      delay: 360,
      event: {
        type: "node_end",
        nodeId: "retrieval",
        payload: {
          output: {
            contexts: contexts
              .filter((item) => item.type === "text")
              .map((item) => ({
                pageNumber: item.pageNumber,
                snippet: item.text.slice(0, 120),
              })),
          },
        },
      },
    },
    {
      delay: 240,
      event: {
        type: "node_start",
        nodeId: "tool-retrieve",
        nodeType: "tool_call",
        label: "Tool call",
        payload: {
          toolName: "retrieve_slide_content",
          input: { pageNumber, k: 4, query: question || "ngữ cảnh slide đã chọn" },
        },
      },
    },
    {
      delay: 320,
      event: {
        type: "node_end",
        nodeId: "tool-retrieve",
        payload: {
          output: {
            hits: [
              "Slide giải thích công thức chính và chú thích ngay cạnh đoạn đã chọn.",
              "Ghi chú bên lề mở rộng cách đọc biểu đồ hoặc ý chính của trang.",
            ],
          },
        },
      },
    },
  ];

  if (hasImage) {
    events.push(
      {
        delay: 220,
        event: {
          type: "node_start",
          nodeId: "tool-ocr",
          nodeType: "tool_call",
          label: "Tool call",
          payload: {
            toolName: "ocr_image",
            input: {
              pageNumber,
              imageCount: contexts.filter((item) => item.type === "image").length,
            },
          },
        },
      },
      {
        delay: 360,
        event: {
          type: "node_end",
          nodeId: "tool-ocr",
          payload: {
            output: {
              extracted: [
                "Phát hiện ký hiệu công thức trong vùng ảnh đính kèm",
                "Phát hiện nhãn biểu đồ và mô tả sơ bộ",
              ],
            },
          },
        },
      },
    );
  }

  if (hasFile) {
    events.push(
      {
        delay: 220,
        event: {
          type: "node_start",
          nodeId: "tool-file",
          nodeType: "tool_call",
          label: "Tool call",
          payload: {
            toolName: "parse_document_layout",
            input: {
              fileCount: contexts.filter((item) => item.type === "file").length,
            },
          },
        },
      },
      {
        delay: 360,
        event: {
          type: "node_end",
          nodeId: "tool-file",
          payload: {
            output: {
              extracted: ["Đã nhận diện tệp PDF đính kèm và sẵn sàng parse layout khi cần."],
            },
          },
        },
      },
    );
  }

  events.push(
    {
      delay: 240,
      event: {
        type: "node_start",
        nodeId: "generation",
        nodeType: "llm_generation",
        label: "LLM generation node",
        payload: {
          input: {
            question,
            contextCount: contexts.length,
          },
        },
      },
    },
    {
      delay: 640,
      event: {
        type: "node_end",
        nodeId: "generation",
        payload: {
          output: {
            answerPreview: createAnswer(question, contexts, pageNumber).slice(0, 120),
          },
        },
      },
    },
  );

  for (const item of events) {
    await wait(item.delay);
    onEvent(item.event);
  }

  return {
    id:
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `assistant-${Date.now()}`,
    role: "assistant",
    content: createAnswer(question, contexts, pageNumber),
    pageNumber,
  };
}

export function applyTraceEvent(current: TraceStep[], event: TraceStreamEvent): TraceStep[] {
  if (event.type === "node_start") {
    const next: TraceStep = {
      id: event.nodeId,
      nodeType: event.nodeType,
      label: event.label,
      status: "running",
      startedAt: new Date().toISOString(),
      input: event.payload?.input,
      toolName: event.payload?.toolName,
      branchLabel: event.payload?.branchLabel,
    };
    return [...current.filter((step) => step.id !== event.nodeId), next];
  }

  return current.map((step) =>
    step.id === event.nodeId
      ? {
          ...step,
          status: event.type === "node_error" ? "error" : "completed",
          endedAt: new Date().toISOString(),
          output: event.payload?.output,
        }
      : step,
  );
}
